﻿namespace PI_Motion
{
    internal class type
    {
    }
}